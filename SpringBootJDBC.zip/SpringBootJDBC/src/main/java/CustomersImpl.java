import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class CustomersImpl implements CustomerRepository {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public int save(Customers customers) {
        return jdbcTemplate.update(
                "insert into customers (customerid,firstname,lastname,gender, address" +
                        "phone, email, city, country) Values (?,?,?,?,?,?,?,?,?)",
                customers.getCustomerid(),
                customers.getFirstname(),
                customers.getLastname(),
                customers.getGender(),
                customers.getAddress(),
                customers.getPhone(),
                customers.getEmail(),
                customers.getCity(),
                customers.getCountry()
        );
    }

    @Override
    public int update(Customers customers) {
        return 0;
    }

    @Override
    public int deleteById(int id) {
        return 0;
    }

    @Override
    public List findAll() {
        return jdbcTemplate.query("select * from customers",
                (rs, rowNum) ->
                new Customers(
                        rs.getInt("customerid"),
                        rs.getString("firstname"),
                        rs.getString("lastname"),
                        rs.getString("gender"),
                        rs.getString("address"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("city"),
                        rs.getString("country")

                ));
    }

    @Override
    public Optional findById(int id) {
        return Optional.empty();
    }
}
