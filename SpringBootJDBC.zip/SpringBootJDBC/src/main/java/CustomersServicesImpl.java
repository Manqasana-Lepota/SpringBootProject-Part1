import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomersServicesImpl implements CustomersServices {

    @Autowired
    CustomerRepository customerRepository;

    @Override
    public int save(Customers customers) {
        return customerRepository.save(customers);
    }

    @Override
    public int update(Customers customers) {
        return customerRepository.update(customers);
    }

    @Override
    public int deleteById(int id) {
        return customerRepository.deleteById(id);
    }

    @Override
    public List findAll() {
        return customerRepository.findAll();
    }

    @Override
    public Optional findById(int id) {
        return customerRepository.findById(id);
    }
}
