import java.util.List;
import java.util.Optional;

public interface CustomerRepository {
    int save(Customers customers);
    int update(Customers customers);
    int deleteById(int id);
    List findAll();
    Optional findById(int id);
}
