import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class SpringBootJdbcApplication implements CommandLineRunner {

    /*spring boot will do auto configure*/
    @Autowired
    CustomersServices customersServices;

    public static void main(String[]args) {
        SpringApplication.run(SpringBootJdbcApplication.class,args);
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("StartApplication...");
        testCustomerData();

    }

    private void testCustomerData() {
        List customers = Arrays.asList(
                new Customers(1, "John", "Hibert", "Male", "284 chaucer st", "084789657", "john@gmail.com", "Johannesburg", "South Africa"),
                new Customers(2, "Thando", "Sithole", "Female", "240 Sect 1", "0794445584", "thando@gmail.com", "Cape Town", "South Africa"),
                new Customers(3, "Leon", "Glen", "Male", "81 Everton Rd,Gillits", "0820832830", "Leon@gmail.com", "Durban", "South Africa"),
                new Customers(4, "Charl", "Muller", "Male", "290A Dorset Ecke", "+448568725", "Charl.muller@yahoo.com", "Berlin", "Germany"),
                new Customers(5, "Julia", "Stein", "Female", "2 Wernerring", "+448672445", "Js234@yahoo.com", "Frankfurt", "Germany")
        );
        System.out.println("[SAVE]");
        customersServices.save((Customers) customers);
    }
}
